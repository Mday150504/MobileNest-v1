# TODO: Add Navbar to Login/Dashboard Pages

## Tasks

- [x] Update user/login.php to include standard navbar from includes/header.php
- [x] Update admin/dashboard.php to replace custom navbar with standard navbar from includes/header.php
- [x] Test the changes to ensure navbar displays correctly and login logic remains unchanged
